== Readme ==

/*
 Simple and easy for modification, PHP script for SMS receiving.
 Proovl SMS number with Mysql database connection. Receive SMS to database MySQL. 
 https://www.proovl.com/numbers

 Video Istruction:
 https://www.youtube.com/watch?v=bdMM6O3uTl8
 
 Istruction:
 
1. Set up your database connection. File - (dbconnection.php)
2. Import Mysql table from sql file. File - (dbmysql.sql)
3. Connect “do.php” file with Proovl SMS number (forward sms to URL). File - (do.php)
4. Upload files on server.
 
*/